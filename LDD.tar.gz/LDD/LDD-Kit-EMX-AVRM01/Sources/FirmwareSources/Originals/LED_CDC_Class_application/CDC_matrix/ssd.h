#ifndef _SSD_H_
#define _SSD_H_

#define STROBE_HI	PORTD |= (1 << PORTD4)
#define STROBE_LOW	PORTD &= ~(1 << PORTD4)

#define DATA_HI		PORTD |= (1 << PORTD1)
#define DATA_LOW	PORTD &= ~(1 << PORTD1)

#define CLOCK_SSD  	PORTD |= (1 << PORTD0);\
    			PORTD &= ~(1 << PORTD0)

#define SSDEN_LOW PORTC &= ~_BV(PORTC2)
#define SSDEN_HI PORTC |= _BV(PORTC2) 					

#define SSD_DELAY 1

#define SSD_0 0x88
#define SSD_1 0xBE
#define SSD_2 0xC4
#define SSD_3 0x94
#define SSD_4 0xB2
#define SSD_5 0x91
#define SSD_6 0x81
#define SSD_7 0xBC
#define SSD_8 0x80
#define SSD_9 0x90

#define SSD_A 0xA0
#define SSD_B 0x83
#define SSD_C 0xC9
#define SSD_D 0x86
#define SSD_E 0xC1

#define SSD_F 0xE1
#define SSD_G 0x90
#define SSD_H 0xA2
#define SSD_I 0xEB
#define SSD_J 0x8C

#define SSD_K 0xAA
#define SSD_L 0xCB
#define SSD_M 0xAA
#define SSD_N 0xAA
#define SSD_O 0x87

#define SSD_P 0xE0
#define SSD_Q 0xAA
#define SSD_R 0xE7
#define SSD_S 0x91
#define SSD_T 0xC3

#define SSD_U 0x8A
#define SSD_V 0xAA
#define SSD_W 0xAA
#define SSD_X 0xAA
#define SSD_Y 0x92

#define SSD_Z 0xAA
#define SSD_ERR 0xAA

#define MAX_SSD_NUM 0x04

void ssd_init_io_port(void);
void ssd_set(unsigned char num, unsigned char val);
void clock_ssd();
void ssd_set_all(const unsigned char *dat);

#endif
