/*
   LUFA Library
   Copyright (C) Dean Camera, 2009.

   dean [at] fourwalledcubicle [dot] com
   www.fourwalledcubicle.com
 */

/*
   Copyright 2009  Dean Camera (dean [at] fourwalledcubicle [dot] com)

   Permission to use, copy, modify, and distribute this software
   and its documentation for any purpose and without fee is hereby
   granted, provided that the above copyright notice appear in all
   copies and that both that the copyright notice and this
   permission notice and warranty disclaimer appear in supporting
   documentation, and that the name of the author not be used in
   advertising or publicity pertaining to distribution of the
   software without specific, written prior permission.

   The author disclaim all warranties with regard to this
   software, including all implied warranties of merchantability
   and fitness.  In no event shall the author be liable for any
   special, indirect or consequential damages or any damages
   whatsoever resulting from loss of use, data or profits, whether
   in an action of contract, negligence or other tortious action,
   arising out of or in connection with the use or performance of
   this software.
 */


/** \file
 *
 *  Main source file for the CDC demo. This file contains the main tasks of
 *  the demo and is responsible for the initial application hardware configuration.
 */

#include "CDC.h"
#include "led.h"
//extra
#include <util/delay.h>
#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>
#include <avr/power.h>
#include <LUFA/Drivers/Peripheral/SerialStream.h>


/** LUFA CDC Class driver interface configuration and state information. This structure is
 *  passed to all CDC Class driver functions, so that multiple instances of the same class
 *  within a device can be differentiated from one another.
 */
USB_ClassInfo_CDC_Device_t VirtualSerial_CDC_Interface =
{
    .Config =
    {
	.ControlInterfaceNumber     = 0,

	.DataINEndpointNumber       = CDC_TX_EPNUM,
	.DataINEndpointSize         = CDC_TXRX_EPSIZE,

	.DataOUTEndpointNumber      = CDC_RX_EPNUM,
	.DataOUTEndpointSize        = CDC_TXRX_EPSIZE,

	.NotificationEndpointNumber = CDC_NOTIFICATION_EPNUM,
	.NotificationEndpointSize   = CDC_NOTIFICATION_EPSIZE,
    },
};

#if 0
/* NOTE: Here you can set up a standard stream using the created virtual serial port, so that the standard stream functions in
 *       <stdio.h> can be used on the virtual serial port (e.g. fprintf(&USBSerial, "Test"); to print a string).
 */

static int CDC_putchar(char c, FILE *stream)
{
    CDC_Device_SendByte(&VirtualSerial_CDC_Interface, c);
    return 0;
}

static int CDC_getchar(FILE *stream)
{
    if (!(CDC_Device_BytesReceived(&VirtualSerial_CDC_Interface)))
	return -1;

    return CDC_Device_ReceiveByte(&VirtualSerial_CDC_Interface);
}

static FILE USBSerial = FDEV_SETUP_STREAM(CDC_putchar, CDC_getchar, _FDEV_SETUP_RW);
#endif

bool led_scrl_flag, led_val_set;
volatile unsigned char *str_index;
    
void Process_led_Command(const char *cmd)
{
    if (strcmp(cmd, "led-on")==0) 
    {
	on_leds();
	led_scrl_flag = 0;
	//CDC_Device_SendString(&VirtualSerial_CDC_Interface, "leds on\r\n", 9);
    }
    
    else if (strcmp(cmd, "led-scroll")==0) 
    {
	led_scrl_flag = 1;
	//CDC_Device_SendString(&VirtualSerial_CDC_Interface, "leds scroll\r\n", 13);
    }
    
    else if (strncmp(cmd, "led-set:",8)==0) 
    {
	str_index = cmd + 8;
	led_val_set = 1;
	led_scrl_flag = 0;
	//CDC_Device_SendString(&VirtualSerial_CDC_Interface, "leds scroll\r\n", 13);
    }


    else if (strcmp(cmd, "led-off")==0) 
    {
	off_leds();
	led_scrl_flag = 0;
	//CDC_Device_SendString(&VirtualSerial_CDC_Interface, "leds off\r\n", 10);
    }

    else 
    {
	/*
	CDC_Device_SendString(&VirtualSerial_CDC_Interface, "unknown command: ", 18);
	CDC_Device_SendString(&VirtualSerial_CDC_Interface, cmd, strlen(cmd));
	CDC_Device_SendString(&VirtualSerial_CDC_Interface, "\r\n", 2);
	*/
    }
}


/** Main program entry point. This routine contains the overall program flow, including initial
 *  setup of all components and the main program loop.
 */
int main(void)
{
    char strbuf[100];
    size_t strpos = 0;
    SetupHardware();

    /*Initialise the I/O ports of LED*/
    init_led_io();
	
    for (;;)
    {
	//CheckJoystickMovement();

	while (CDC_Device_BytesReceived(&VirtualSerial_CDC_Interface)) 

	{
	    strbuf[strpos] = CDC_Device_ReceiveByte(&VirtualSerial_CDC_Interface);

	    if (strbuf[strpos] == '\r' || strbuf[strpos] == 0) 
	    {
		strbuf[strpos] = 0;
		printf("Received string %s\r\n", strbuf);
		continue;
	    }

	    else if (strbuf[strpos] == '\n') 
	    {
		strbuf[strpos] = 0;
		printf("Received string %s\r\n", strbuf);

		Process_led_Command(strbuf);

		strpos = 0;
	    }

	    else 
	    {
		strpos++;
	    }

	}

	CDC_Device_USBTask(&VirtualSerial_CDC_Interface);
	USB_USBTask();
    }

}

volatile unsigned char val;
volatile unsigned int timer;
/* timer function */
ISR(TIMER0_OVF_vect)
{
    timer++;
    if(timer > 50 && led_scrl_flag == 1)
    {	
	if (val == 0)
	    val = 0x80;

	set_leds(val);

   	val = val >> 1;    
        timer = 0;
    }
    
    if(led_val_set == 1 && timer  > 500)
    {
	set_leds(*str_index);
	
	timer = 0;
    	str_index++;
    	
    	if(*str_index == '\0')
	    led_val_set = 0; 

    }	
}

void init_timer(void)
{
    TCCR0B = 0x03;
    TIMSK0 |= (1 << TOIE0);
    sei();
}

/** Configures the board hardware and chip peripherals for the demo's functionality. */
void SetupHardware(void)
{
    /* Disable watchdog if enabled by bootloader/fuses */
    MCUSR &= ~(1 << WDRF);
    wdt_disable();

    /* Disable clock division */
    clock_prescale_set(clock_div_1);

    init_timer();

    /* Hardware Initialization */
    //Joystick_Init();
    LEDs_Init();
    USB_Init();
    SerialStream_Init(9600, false);
}

/** Checks for changes in the position of the board joystick, sending strings to the host upon each change. */
void CheckJoystickMovement(void)
{
    uint8_t     JoyStatus_LCL = Joystick_GetStatus();
    char*       ReportString  = NULL;
    static bool ActionSent    = false;

    if (JoyStatus_LCL & JOY_UP)
	ReportString = "Joystick Up\r\n";
    else if (JoyStatus_LCL & JOY_DOWN)
	ReportString = "Joystick Down\r\n";
    else if (JoyStatus_LCL & JOY_LEFT)
	ReportString = "Joystick Left\r\n";
    else if (JoyStatus_LCL & JOY_RIGHT)
	ReportString = "Joystick Right\r\n";
    else if (JoyStatus_LCL & JOY_PRESS)
	ReportString = "Joystick Pressed\r\n";
    else
	ActionSent = false;

    if ((ReportString != NULL) && (ActionSent == false))
    {
	ActionSent = true;

	CDC_Device_SendString(&VirtualSerial_CDC_Interface, ReportString, strlen(ReportString));		
    }
}

/** Event handler for the library USB Connection event. */
void EVENT_USB_Device_Connect(void)
{
    LEDs_SetAllLEDs(LEDMASK_USB_ENUMERATING);
}

/** Event handler for the library USB Disconnection event. */
void EVENT_USB_Device_Disconnect(void)
{
    LEDs_SetAllLEDs(LEDMASK_USB_NOTREADY);
}

/** Event handler for the library USB Configuration Changed event. */
void EVENT_USB_Device_ConfigurationChanged(void)
{
    LEDs_SetAllLEDs(LEDMASK_USB_READY);

    if (!(CDC_Device_ConfigureEndpoints(&VirtualSerial_CDC_Interface)))
	LEDs_SetAllLEDs(LEDMASK_USB_ERROR);
}

/** Event handler for the library USB Unhandled Control Request event. */
void EVENT_USB_Device_UnhandledControlRequest(void)
{
    CDC_Device_ProcessControlRequest(&VirtualSerial_CDC_Interface);
}
