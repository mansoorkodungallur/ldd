#include <avr/io.h>
#include "led.h"

void init_led_io(void)
{
    DDRB |= _BV(PORTB4) | _BV(PORTB5);
}

void set_leds(unsigned char val)
{
    unsigned char num = 8;

    while(num--)
    {
	if(val & 0x80)
	    DATA_LOW;

	else
	    DATA_HI;


	CLOCK_LED;
	val = val << 1;
    }
}

void off_leds(void)
{

    DATA_HI;
    CLOCK_LED;

    DATA_HI;
    CLOCK_LED;

    DATA_HI;
    CLOCK_LED;

    DATA_HI;
    CLOCK_LED;

    DATA_HI;
    CLOCK_LED;

    DATA_HI;
    CLOCK_LED;

    DATA_HI;
    CLOCK_LED;

    DATA_HI;
    CLOCK_LED;

}


void on_leds(void)
{

    DATA_LOW;
    CLOCK_LED;

    DATA_LOW;
    CLOCK_LED;

    DATA_LOW;
    CLOCK_LED;

    DATA_LOW;
    CLOCK_LED;

    DATA_LOW;
    CLOCK_LED;

    DATA_LOW;
    CLOCK_LED;

    DATA_LOW;
    CLOCK_LED;

    DATA_LOW;
    CLOCK_LED;

}
