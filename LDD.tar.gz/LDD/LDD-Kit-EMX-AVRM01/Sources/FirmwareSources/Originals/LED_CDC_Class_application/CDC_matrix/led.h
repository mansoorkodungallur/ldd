#ifndef _LED_H_
#define _LED_H_

#define DATA_HI		PORTB |= (1 << PORTB4)
#define DATA_LOW	PORTB &= ~(1 << PORTB4)

#define CLOCK_LED  	PORTB |= (1 << PORTB5);\
	                PORTB &= ~(1 << PORTB5)

void init_led_io(void);
void off_leds(void);
void on_leds(void);
void set_leds(unsigned char val);
void Process_led_Command(const char *cmd);
#endif
