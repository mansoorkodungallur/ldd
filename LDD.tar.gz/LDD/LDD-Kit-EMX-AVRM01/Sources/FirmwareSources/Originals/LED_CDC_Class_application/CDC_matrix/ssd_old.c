#include <avr/io.h>
#include <util/delay.h>
#include "ssd.h"
void ssd_init_io_port(void)
{
	/*Setting the Data, clock and Strobe pins as output*/
	DDRD |= ((1 << 0) | (1 << 4) | (1 << 6));

	/*Setting the enable pins of SSD's as output)*/
	DDRB |= ((1 << 4) | (1 << 5) | (1 << 6) | (1 << 7));
}

void ssd_set(unsigned char num, unsigned char val)
{
	unsigned char index = 0x08;

	switch (num)
	{
		case 2:
			PORTB = 0x80;
			break;

		case 3:
			PORTB = 0x40;
			break;

		case 4:
			PORTB = 0x20;
			break;

		case 1:
			PORTB = 0x10;
			break;

		default:
			PORTB = 0x00;
			break;
	}

	STROBE_LOW;

	while(index--)
	{

		if(val & 0x01)
	    		DATA_LOW;
	    	else
	    		DATA_HI;
			
		CLOCK_SSD;
			//clock_ssd();
	    val = val >> 1;
	}

	STROBE_HI;
	_delay_ms(2);

}

void clock_ssd()
{
	PORTD |= (1 << PORTD6);
	//_delay_ms(delay);

	PORTD &= ~(1 << PORTD6);
	//_delay_ms(delay);
}

