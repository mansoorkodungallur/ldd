#include <avr/io.h>
#include <util/delay.h>
#include "ssd.h"
void ssd_init_io_port(void)
{
    /*Setting the Data, clock and Strobe pins as output*/
    DDRD |= (_BV(PORTD0) | _BV(PORTD1) | _BV(PORTD4));

    /*Setting the enable pins of SSD's as output)*/
    DDRB |= (_BV(PORTB4) | _BV(PORTB5) | _BV(PORTB6) | _BV(PORTB7));
    
    DDRC |= _BV(PORTC2);

}

static void delay_ssd(unsigned int factor)
{
	while(factor--);
}

void ssd_set(unsigned char num, unsigned char val)
{
    unsigned char index = 0x08;

    STROBE_LOW;
    SSDEN_LOW;


    while(index--)
    {

	if(val & 0x01)
	    DATA_LOW;
	else
	    DATA_HI;

	CLOCK_SSD;
	val = val >> 1;
    }

    PORTB = (PORTB & 0x0F) | (0x08 << num);
    STROBE_HI;
    SSDEN_HI;

}


void ssd_set_all(const unsigned char *dat)
{
    unsigned char index = 0x08,val;
    static unsigned char num;

    
//    STROBE_HI;
    if(num >= 0 && num < 4)
    {   
	val = dat[num];
	STROBE_LOW;
	SSDEN_LOW;

	while(index--)
	{

	    if(val & 0x01)
		DATA_LOW;
	    else
		DATA_HI;

	    CLOCK_SSD;
	    val = val >> 1;
	}

	PORTB = (PORTB & 0x0F) | (0x10 << num);
	//  PORTB = (PORTB & 0x0F) | (0x80 >> num);

	STROBE_HI;
	SSDEN_HI;
    }
    num++; 	

    if(num > (MAX_SSD_NUM + 1))
	num = 0;
}
