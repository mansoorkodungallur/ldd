

/***********************************************
* AnyLink Drop Down Menu- © Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

var burl='http://www.moxa.com';
var burl2='http://web4.moxa.com';


//Contents for menu About Moxa
var menu1=new Array()
menu1[0]='<a class="drop-menu-green" href="' + burl + '/about_moxa/index.htm">About MOXA</a>'
menu1[1]='<a class="drop-menu-green" href="' + burl + '/about_moxa/careers.htm">Careers</a>'
menu1[2]='<a class="drop-menu-green" href="' + burl + '/about_moxa/greenproduct/index.htm">Moxa\'s Green Promise</a>'
//menu1[3]='<a class="drop-menu-green" href="' + burl + '/about_moxa/quality_assurance/index.htm">Quality Assurance</a>'
menu1[3]='<a class="drop-menu-green" href="' + burl + '/about_moxa/moxa_foundation.htm" class="drop-menu-green">The MOXA Foundation</a>'

//Contents for menu product
var menu2=new Array()
menu2[0]='<a class="drop-menu-green" href="' + burl + '/product/Industrial_Ethernet_Switches.htm" >Industrial Ethernet Switches</a>'
menu2[1]='<a class="drop-menu-green" href="' + burl + '/product/Serial_to_Ethernet_Products.htm" >Serial to Ethernet Products</a>'
menu2[2]='<a class="drop-menu-green" href="' + burl + '/product/Wireless_Ethernet_Products.htm" >Wireless Ethernet Products</a>'
menu2[3]='<a class="drop-menu-green" href="' + burl + '/product/Remote_IO_Server.htm" >Remote I/O Server</a>'
menu2[4]='<a class="drop-menu-green" href="' + burl + '/product/Embedded_Computers.htm" >Embedded Computers</a>'
menu2[5]='<a class="drop-menu-green" href="' + burl + '/product/Multiport_Serial_Boards.htm" >Multiport Serial Boards</a>'
menu2[6]='<a class="drop-menu-green" href="' + burl + '/product/Media_Converters.htm" >Media Converters</a>'
menu2[7]='<a class="drop-menu-green" href="' + burl + '/product/Video_Servers.htm" >Video Servers</a>'
menu2[8]='<a class="drop-menu-green" href="' + burl + '/product/USB_to_Serial_Hubs.htm" >USB to Serial Hubs</a>'
menu2[9]='<a class="drop-menu-green" href="' + burl + '/product/Software_Accessories.htm" >Software & Accessories</a>'

//Contents for menu Solutions
var menu3=new Array()
menu3[0]='<a class="drop-menu-green" href="' + burl + '/Zones/Active_Ethernet_IO/index.htm">Active Ethernet I/O</a>'
menu3[1]='<a class="drop-menu-green" href="' + burl + '/Zones/Embedded_Computing/index.htm">Embedded Computing</a>'
menu3[2]='<a class="drop-menu-green" href="' + burl + '/Zones/Industrial_Ethernet/index.htm">Industrial Ethernet</a>'
menu3[3]='<a class="drop-menu-green" href="' + burl + '/Zones/Serial_to_Ethernet/index.htm">Serial-to-Ethernet</a>'
menu3[4]='<a class="drop-menu-green" href="' + burl + '/Zones/Serial_Communication/index.htm">Serial Communication</a>'
menu3[5]='<a class="drop-menu-green" href="' + burl + '/Zones/Wireless_Ethernet/index.htm">Wireless Ethernet</a>'
menu3[6]='<a class="drop-menu-green" href="' + burl + '/Solutions/Solutions.htm#more"><b>More Solutions...</b></a>'
//menu3[2]='<a class="drop-menu-green" href="' + burl + '/Solutions/POSKIOSKATM_Connectivity.htm">POS/KIOSK/ATM Connectivity</a>'
//menu3[3]='<a class="drop-menu-green" href="' + burl + '/solutions/Ethernet-to-Serial_Solution_for_industrial_Automation.htm">Ethernet-to-Serial Solution for Industrial Automation</a>'
//menu3[4]='<a class="drop-menu-green" href="' + burl + '/Solutions/Serial-to-Ethernet_Connectivity.htm">Serial-to-Ethernet Connectivity</a>'
//menu3[5]='<a class="drop-menu-green" href="' + burl + '/Solutions/Remote_Console_Management.htm" >Remote Console Management</a>'
//menu3[6]='<a class="drop-menu-green" href="' + burl + '/Solutions/Remote_Dial-in_Access.htm">Remote Dial-in Access</a>'
//menu3[7]='<a class="drop-menu-green" href="' + burl + '/Solutions/Serial_Programming_&_Debugging.htm">Serial Programming & Debugging</a>'
//menu3[8]='<a class="drop-menu-green" href="' + burl + '/Solutions/Distributed_Video_Networking.htm">Distributed Video Networking</a>'
//menu3[9]='<a class="drop-menu-green" href="' + burl + '/Solutions/Industrial_Ethernet_Connectivity.htm">Industrial Ethernet Connectivity</a>'
menu3[7]='<a class="drop-menu-green" href="' + burl + '/solutions/success_stories.htm" ><b>Success Stories</b></a>'


//Contents for menu Support
var menu4=new Array()
menu4[0]='<a class="drop-menu-green" href="' + burl2 + '/support/technical_support.asp">Request Technical Support</a>'
menu4[1]='<a class="drop-menu-green" href="' + burl + '/support/mtsc_showcase.htm" >MTSC Showcase</a>'
menu4[2]='<a class="drop-menu-green" href="' + burl2 + '/support/rma_service.asp" >RMA Service </a>'
menu4[3]='<a class="drop-menu-green" href="' + burl2 + '/support/download_center.asp">Download Center</a>'
menu4[4]='<a class="drop-menu-green" href="' + burl + '/support/glossary.htm" >Glossary</a>'
menu4[5]='<a class="drop-menu-green" href="' + burl + '/support/warranty.htm" >Product Warranty </a>'
menu4[6]='<a class="drop-menu-green" href="' + burl2 + '/support/faq.asp" >FAQ</a>'
//menu4[7]='<a class="drop-menu-green" href="' + burl + '/support/customer_care_center.htm" >Customer Care Center</a>'


//Contents for menu News
var menu5=new Array()
menu5[0]='<a class="drop-menu-green" href="' + burl + '/news_events/press_room.htm" >News</a>'
menu5[1]='<a class="drop-menu-green" href="' + burl + '/news_events/event_calendar.htm" >Upcoming Events </a>'
menu5[2]='<a class="drop-menu-green" href="' + burl + '/news_events/moxa_connection.htm" class="drop-menu-green">E-Newsletters</a>'
//menu5[3]='<a class="drop-menu-green" href="' + burl + '/news_events/Subscribe_Unsubscribe.htm" class="drop-menu-green">Subscribe/Unsubscribe</a>'


//Contents for menu Where to buy
var menu6=new Array()
menu6[0]='<a class="drop-menu-green" href="' + burl + '/usa/where_to_buy/partner_North_America.htm" >North America</a>'
menu6[1]='<a class="drop-menu-green" href="' + burl + '/usa/where_to_buy/partner_central_america.htm" >Central America</a>'
menu6[2]='<a class="drop-menu-green" href="' + burl + '/usa/where_to_buy/partner_south_america.htm" >South America</a>'
menu6[3]='<a class="drop-menu-green" href="' + burl + '/where_to_buy/partner_Europe__Russia__Africa.htm">Europe / Russia / Africa</a>'
menu6[4]='<a class="drop-menu-green" href="' + burl + '/where_to_buy/partner_Middle_East__Asia_Pacific.htm">Middle East / Asia Pacific</a>'
menu6[5]='<a class="drop-menu-green" href="' + burl + '/where_to_buy/partner_China.htm">China</a>'




var menuwidth='300px' //default menu width
var menubgcolor='ffffff'  //menu bgcolor
var disappeardelay=100  //menu disappear speed onMouseout (in miliseconds)
var hidemenu_top_onclick="yes" //hide menu when user clicks within menu?

/////No further editting needed

var ie4=document.all
var ns6=document.getElementById&&!document.all

if (ie4||ns6)
document.write('<div id="dropmenudiv" style="visibility:hidden;width:'+menuwidth+';background-color:'+menubgcolor+'" onMouseover="clearhidemenu_top_top()" onMouseout="dynamichide_top(event)"></div>')

function getposOffset(what, offsettype){
var totaloffset=(offsettype=="left")? what.offsetLeft : what.offsetTop;
var parentEl=what.offsetParent;
while (parentEl!=null){
totaloffset=(offsettype=="left")? totaloffset+parentEl.offsetLeft : totaloffset+parentEl.offsetTop;
parentEl=parentEl.offsetParent;
}
return totaloffset;
}


function showhide(obj, e, visible, hidden, menuwidth){
if (ie4||ns6)
dropmenuobj.style.left=dropmenuobj.style.top=-500
if (menuwidth!=""){
dropmenuobj.widthobj=dropmenuobj.style
dropmenuobj.widthobj.width=menuwidth
}
if (e.type=="click" && obj.visibility==hidden || e.type=="mouseover")
obj.visibility=visible
else if (e.type=="click")
obj.visibility=hidden
}

function iecompattest_top(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function clearbrowseredge(obj, whichedge){
var edgeoffset=0
if (whichedge=="rightedge"){
var windowedge=ie4 && !window.opera? iecompattest_top().scrollLeft+iecompattest_top().clientWidth-15 : window.pageXOffset+window.innerWidth-15
dropmenuobj.contentmeasure=dropmenuobj.offsetWidth
if (windowedge-dropmenuobj.x < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure-obj.offsetWidth
}
else{
var topedge=ie4 && !window.opera? iecompattest_top().scrollTop : window.pageYOffset
var windowedge=ie4 && !window.opera? iecompattest_top().scrollTop+iecompattest_top().clientHeight-15 : window.pageYOffset+window.innerHeight-18
dropmenuobj.contentmeasure=dropmenuobj.offsetHeight
if (windowedge-dropmenuobj.y < dropmenuobj.contentmeasure){ //move up?
edgeoffset=dropmenuobj.contentmeasure+obj.offsetHeight
if ((dropmenuobj.y-topedge)<dropmenuobj.contentmeasure) //up no good either?
edgeoffset=dropmenuobj.y+obj.offsetHeight-topedge
}
}
return edgeoffset
}

function populatemenu(what){
if (ie4||ns6)
dropmenuobj.innerHTML=what.join("")
}


function dropdownmenu(obj, e, menucontents, menuwidth){
if (window.event) event.cancelBubble=true
else if (e.stopPropagation) e.stopPropagation()
clearhidemenu_top_top()
dropmenuobj=document.getElementById? document.getElementById("dropmenudiv") : dropmenudiv
populatemenu(menucontents)

if (ie4||ns6){
showhide(dropmenuobj.style, e, "visible", "hidden", menuwidth)
dropmenuobj.x=getposOffset(obj, "left")-8
dropmenuobj.y=getposOffset(obj, "top") +2
dropmenuobj.style.left=dropmenuobj.x-clearbrowseredge(obj, "rightedge")+"px"
dropmenuobj.style.top=dropmenuobj.y-clearbrowseredge(obj, "bottomedge")+obj.offsetHeight+"px"
}

return clickreturnvalue()
}

function clickreturnvalue(){
if (ie4||ns6) return false
else return true
}

function contains_ns6_top(a, b) {
while (b.parentNode)
if ((b = b.parentNode) == a)
return true;
return false;
}

function dynamichide_top(e){
if (ie4&&!dropmenuobj.contains(e.toElement))
delayhidemenu_top()
else if (ns6&&e.currentTarget!= e.relatedTarget&& !contains_ns6_top(e.currentTarget, e.relatedTarget))
delayhidemenu_top()
}

function hidemenu_top(e){
if (typeof dropmenuobj!="undefined"){
if (ie4||ns6)
dropmenuobj.style.visibility="hidden"
}
}

function delayhidemenu_top(){
if (ie4||ns6)
delayhide=setTimeout("hidemenu_top()",disappeardelay)
}

function clearhidemenu_top_top(){
if (typeof delayhide!="undefined")
clearTimeout(delayhide)
}

if (hidemenu_top_onclick=="yes")
document.onclick=hidemenu_top

