var burl='http://www.moxa.com';
var burl2='http://web4.moxa.com';

var str='';
var str= str + '<table width="100%" height="75" border="0" cellpadding="0" cellspacing="0" bgcolor="#009881">';
var str = str + '<tr><td width="12">&nbsp;</td>';
var str= str + '<td width="141"><a href="' + burl + '/index.htm"><img src="' + burl + '/images/moxa_logo.gif" width="141" height="75" border="0"></a></td>';
var str = str +'<td><div align="right">';
var str = str + '<table width="80%" height="21" border="0" cellpadding="0" cellspacing="0">';
//var str = str + '<tr><td align="right"><table><tr>';
//var str = str + '<td width="24"><a href="http://www.moxa.com/usa/" ><img alt="United Ststes" border="0" src="/images/country_flag/home_US.gif"></a></td><td width="1"></td>';
//var str = str + '<td width="24"><a href="http://www.moxa.com.cn/"><img alt="China" border="0" src="/images/country_flag/home_china.gif"></a><td width="1"></td>';
//var str = str + '<td width="24"><a href="http://www.moxa.com.tw/"><img alt="Taiwan" border="0" src="/images/country_flag/home_taiwan.gif"></a></td><td width="1"></td>';
//var str = str + '<td width="24"><a href="http://japan.moxa.com/"><img alt="Japan" border="0" src="/images/country_flag/home_japan.gif"></a></td>';
//var str = str + '</tr></table>'
//var str = str + '</td></tr>'
var str = str + '<tr><form action="' + burl2 + '/search_results.asp" method="get" name="site_search">';
var str = str + '<td align="right"  class="top-menu-green"><a href="' + burl + '/index.htm" class="top-menu-green">Home</a> | <a href="http://web4.moxa.com/Tree/MoxaWebProductTree.asp" class="top-menu-green">My Price Requests</a> | <a href="' + burl + '/contact_moxa/index.htm" class="top-menu-green">Contact Moxa</a> | <a href="' + burl + '/sitemap.htm" class="top-menu-green">Sitemap</a></td>';
var str = str  +'</form></tr></table>';
var str = str  + '<table width="80%" height="21" border="0" cellpadding="0" cellspacing="0">';
var str = str  + '<tr><form action="' + burl2 + '/search_results.asp" method="get" name="site_search">';
var str = str  +  '<td align="right"  class="top-menu-green"><div align="right">';
var str = str  +  '<input name="keyword" type="text" class="search-site"  onclick=this.value=""  value="search site"   size="20" maxlength="20">';
var str = str  +  '<input name="Submit" type="submit" class="btn-go2" value=" Go ">';
var str = str  +  '</div></td></form></tr></table>';
var str = str  +  '</div></td>';
var str = str  +   '<td width="12" bgcolor="#009881"></td></tr></table>' ;


document.write (str);

