var str='';

str = str +'<select name="region" class="box-region" onchange="location.href=this.form.region.options[this.form.region.selectedIndex].value">            <option selected value="">--- Other Moxa Websites ---</option> <!--<option value="http://www.moxa.com/">Global</option>-->			<option value="http://www.moxa.com/usa/">The Americas</option>			<option value="http://www.moxa.com.cn">China</option>            <option value="http://www.moxa.com.tw">Taiwan</option>			<option value="http://japan.moxa.com">Japan</option>			</select>';
document.write (str);
