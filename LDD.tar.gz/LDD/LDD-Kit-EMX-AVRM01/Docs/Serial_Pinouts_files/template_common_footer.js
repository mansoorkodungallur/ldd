var burl='http://www.moxa.com';
var burl2='http://web4.moxa.com';

var str='';
var str= str + '<table width="100%" border="0" align="right" cellpadding="0" cellspacing="0" class="top-menu-green">';
var str= str + '<tr><td width="10">&nbsp;</td>';
var str= str + '<td>ISO9001:2000 Certified</td>';
var str= str + '<td width="200"><div align="right">';
var str= str + '<a href="' + burl + '/about_moxa/privacy.htm" class="top-menu-green">Privacy</a> | ';
var str= str + '<a href="' + burl2 + '/contact/comments_feedback.asp" class="top-menu-green">Feedback</a>';
var str= str + '</div></td>';
var str= str + '<td align="right" width="10">&nbsp;</td></tr></table>';
var str= str + '</td></tr>';
var str= str + '<tr><td bgcolor="#009881" height="20">'; 
var str= str + '<table width="100%" border="0" cellspacing="0" cellpadding="0" >';
var str= str + '<tr><td class="copyright" align="center" width="10"></td>';
var str= str + '<td class="copyright">&copy;2005 The Moxa Group. All rights reserved.</td>';
var str= str + '<td width="180" class="copyright"><div align="right">Last updated Feb. 15, 2007</div></td>';
var str= str + '<td width="10" class="copyright"></td></tr>';
var str= str + '</table>';


document.write (str);

