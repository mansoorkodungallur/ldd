
                
                


/***********************************************
* Pop-it menu- ?Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

var defaultMenuWidth="200px" //set default menu width.

var linkset=new Array()
//SPECIFY MENU SETS AND THEIR LINKS. FOLLOW SYNTAX LAID OUT

linkset[1]='<table class="main-content"><tr><td height="14">'
linkset[1]+='<a href="/product/Managed_Redundant_Switches.htm"><img border="0" src="../../images/tri.gif">Managed Redundant Switches</a>'
linkset[1]+='</td></tr><tr><td height="14">'
//linkset[1]+='<hr size="1">' //Optional Separator
linkset[1]+='<a href="/product/Unmanaged_Switches.htm"><img border="0" src="../../images/tri.gif">Unmanaged Switches</a>'
linkset[1]+='</td></tr></table>'
//linkset[0]+='<a href="http://www.codingforums.com">Coding Forums</a>'
//linkset[0]+='<a href="http://www.cssdrive.com">CSS Drive</a>'
//linkset[0]+='<a href="http://freewarejava.com">Freewarejava</a>'

linkset[2]='<table class="main-content"><tr><td height="14">'
linkset[2]+='<a href="/product/Wireless_Device_Servers.htm"><img border="0" src="../../images/tri.gif">Wireless Device Servers</a>'
linkset[2]+='</td></tr><tr><td height="14">'
linkset[2]+='<a href="/product/AWK-1100.htm"><img border="0" src="../../images/tri.gif">Wireless AP/Bridge/AP Client</a>'
linkset[2]+='</td></tr></table>'


linkset[3]='<table class="main-content"><tr><td height="14">'
linkset[3]+='<a href="/product/Embedded_Computers_rackmount.htm" ><img border="0" src="../../images/tri.gif">Rackmount </a>'
linkset[3]+='</td></tr><tr><td height="14">'
linkset[3]+='<a href="/product/Embedded_Computers_din-rail.htm" ><img border="0" src="../../images/tri.gif">Rugged/ DIN-Rail </a>'
linkset[3]+='</td></tr><tr><td height="14">'
linkset[3]+='<a href="/product/Embedded_Computers_boxcomputers.htm" ><img border="0" src="../../images/tri.gif">Box Computers  </a>'
linkset[3]+='</td></tr><tr><td height="14">'
linkset[3]+='<a href="/product/Embedded_Computers_wide-temperature.htm" ><img border="0" src="../../images/tri.gif">Wide Temperature</a>'
linkset[3]+='</td></tr><tr><td height="14">'
linkset[3]+='<a href="/product/Embedded_Computers_embedded-module.htm" ><img border="0" src="../../images/tri.gif">Emedded Module</a>'
linkset[3]+='</td></tr></table>'


linkset[4]='<table class="main-content"><tr><td height="14">'
linkset[4]+='<a href="/product/Industrial_Video_Servers.htm" ><img border="0" src="../../images/tri.gif">Industrial Video Servers</a>'
linkset[4]+='</td></tr><tr><td height="14">'
linkset[4]+='<a href="/product/General_Video_Servers.htm" ><img border="0" src="../../images/tri.gif">General Video Servers</a>'
linkset[4]+='</td></tr></table>'

linkset[5]='<table class="main-content"><tr><td height="14">'
linkset[5]+='<a href="/product/External_Device_Servers.htm" ><img border="0" src="../../images/tri.gif">External Device Servers</a>'
linkset[5]+='</td></tr><tr><td height="14">'
linkset[5]+='<a href="/product/Embedded_Device_Servers.htm" ><img border="0" src="../../images/tri.gif">Embedded Device Servers</a>'
linkset[5]+='</td></tr><tr><td height="14">'
linkset[5]+='<a href="/product/Terminal_Servers.htm" ><img border="0" src="../../images/tri.gif">Terminal Servers </a>'
linkset[5]+='</td></tr><tr><td height="14">'
linkset[5]+='<a href="/product/Modbus_Gateways.htm" ><img border="0" src="../../images/tri.gif">Modbus Gateways</a>'
//linkset[5]+='</td></tr><tr><td height="14">'
//linkset[5]+='<a href="/Temp/product/Programmable_Gateways.htm" ><img border="0" src="../../images/tri.gif">Programmable Gateways</a>'
linkset[5]+='</td></tr></table>'

linkset[6]='<table class="main-content"><tr><td height="14">'
linkset[6]+='<a href="/product/PCI_Express_Boards.htm" ><img border="0" src="../../images/tri.gif">PCI Express</a>'
linkset[6]+='</td></tr><tr><td height="14">'
linkset[6]+='<a href="/product/Universal_PCI_Boards.htm" ><img border="0" src="../../images/tri.gif">Universal PCI </a>'
linkset[6]+='</td></tr><tr><td height="14">'
linkset[6]+='<a href="/product/PCI_Boards.htm" ><img border="0" src="../../images/tri.gif">PCI</a>'
linkset[6]+='</td></tr><tr><td height="14">'
linkset[6]+='<a href="/product/ISA_Boards.htm" ><img border="0" src="../../images/tri.gif">ISA </a>'
linkset[6]+='</td></tr><tr><td height="14">'
linkset[6]+='<a href="/product/PC_104_Boards.htm"><img border="0" src="../../images/tri.gif">PC/104</a>'
linkset[6]+='</td></tr></table>'
                  
linkset[7]='<table class="main-content"><tr><td height="14">'	  
linkset[7]+='<a href="/product/TCF-142.htm" ><img border="0" src="../../images/tri.gif">Serial to Fiber Converters</a>'
linkset[7]+='</td></tr><tr><td height="14">'
linkset[7]+='<a href="/product/Ethernet_to_Fiber_Converters.htm" ><img border="0" src="../../images/tri.gif">Ethernet to Fiber Converters</a>'
linkset[7]+='</td></tr><tr><td height="14">'
linkset[7]+='<a href="/product/RS-232_to_RS-422_485_Converters.htm" ><img border="0" src="../../images/tri.gif">RS-232 to RS-422/485 Converters</a>'
linkset[7]+='</td></tr><tr><td height="14">'
linkset[7]+='<a href="/product/Repeaters_Isolators.htm"><img border="0" src="../../images/tri.gif">Repeaters & Isolators</a>'
linkset[7]+='</td></tr></table>'


linkset[8]='<table class="main-content"><tr><td height="14">'	  
linkset[8]+='<a href="/product/RS-232_over_USB.htm" ><img border="0" src="../../images/tri.gif">RS-232 over USB</a>'
linkset[8]+='</td></tr><tr><td height="14">'
linkset[8]+='<a href="/product/NPort_1220.htm" ><img border="0" src="../../images/tri.gif">RS-422/485 over USB</a>'
linkset[8]+='</td></tr></table>'


linkset[9]='<table class="main-content"><tr><td height="14">'	  
linkset[9]+='<a href="/product/Active_Ethernet_IO_Server.htm" ><img border="0" src="../../images/tri.gif">Active Ethernet I/O Server</a>'
linkset[9]+='</td></tr><tr><td height="14">'
linkset[9]+='<a href="/product/Serial_Remote_IO_Server.htm" ><img border="0" src="../../images/tri.gif">Serial Remote I/O Server</a>'
linkset[9]+='</td></tr><tr><td height="14">'

linkset[9]+='<a href="/product/ioLogik-4000.htm" ><img border="0" src="../../images/tri.gif">Expandable Remote I/O Server</a>'
linkset[9]+='</td></tr></table>'


                  
                  

                


////No need to edit beyond here

var ie5=document.all && !window.opera
var ns6=document.getElementById

if (ie5||ns6)
document.write('<div  id="popitmenu" onMouseover="clearhidemenu();" onMouseout="dynamichide(event)"></div>')

function iecompattest(){
return (document.compatMode && document.compatMode.indexOf("CSS")!=-1)? document.documentElement : document.body
}

function showmenu(e, which, optWidth){
if (!document.all&&!document.getElementById)
return
clearhidemenu()
menuobj=ie5? document.all.popitmenu : document.getElementById("popitmenu")
menuobj.innerHTML=which
menuobj.style.width=(typeof optWidth!="undefined")? optWidth : defaultMenuWidth
menuobj.contentwidth=menuobj.offsetWidth
menuobj.contentheight=menuobj.offsetHeight
eventX=ie5? event.clientX : e.clientX
eventY=ie5? event.clientY : e.clientY
//Find out how close the mouse is to the corner of the window
var rightedge=ie5? iecompattest().clientWidth-eventX : window.innerWidth-eventX
var bottomedge=ie5? iecompattest().clientHeight-eventY : window.innerHeight-eventY
//if the horizontal distance isn't enough to accomodate the width of the context menu
if (rightedge<menuobj.contentwidth)
//move the horizontal position of the menu to the left by it's width
menuobj.style.left=ie5? iecompattest().scrollLeft+eventX-menuobj.contentwidth+"px" : window.pageXOffset+eventX-menuobj.contentwidth+"px"
else
//position the horizontal position of the menu where the mouse was clicked
menuobj.style.left=ie5? iecompattest().scrollLeft+eventX+"px" : window.pageXOffset+eventX+"px"
//same concept with the vertical position
if (bottomedge<menuobj.contentheight)
menuobj.style.top=ie5? iecompattest().scrollTop+eventY-menuobj.contentheight+"px" : window.pageYOffset+eventY-menuobj.contentheight+"px"
else
menuobj.style.top=ie5? iecompattest().scrollTop+event.clientY+"px" : window.pageYOffset+eventY+"px"
menuobj.style.visibility="visible"
return false
}

function contains_ns6(a, b) {
//Determines if 1 element in contained in another- by Brainjar.com
while (b.parentNode)
if ((b = b.parentNode) == a)
return true;
return false;
}

function hidemenu(){
if (window.menuobj)
menuobj.style.visibility="hidden"
}

function dynamichide(e){
if (ie5&&!menuobj.contains(e.toElement))
hidemenu()
else if (ns6&&e.currentTarget!= e.relatedTarget&& !contains_ns6(e.currentTarget, e.relatedTarget))
hidemenu()
}

function delayhidemenu(){
delayhide=setTimeout("hidemenu()",500)
}

function clearhidemenu(){
if (window.delayhide)
clearTimeout(delayhide)
}

if (ie5||ns6)
document.onclick=hidemenu





function function_Embedded___Programmable_menu()
{ 
//if( Embedded___Programmable_menu.style.display == "none") 
//{
//Embedded___Programmable_menu.style.display = "block";
//} 
//else 
//Embedded___Programmable_menu.style.display = "none";
//}
//if (document.images['Embedded___Programmable_arrow'].src == "/images/lft_m_arrow_d.gif")
//{
//document.images['Embedded___Programmable_arrow'].src = '/images/lft_m_arrow_r.gif'
}

function Industrial_Ethernet_menu()
{ 
//if( Industrial_Ethernet_menu.style.display == "none") 
//{
//Industrial_Ethernet_menu.style.display = "block";
//} 
//else 
//Industrial_Ethernet_menu.style.display = "none";
//}
//if (document.images['Industrial_Ethernet_arrow'].src == "/images/lft_m_arrow_d.gif")
//{
//document.images['Industrial_Ethernet_arrow'].src = '/images/lft_m_arrow_r.gif'
}

function function_PC_based_Serial_menu()
{ 
//if( PC_based_Serial_menu.style.display == "none") 
//{
//PC_based_Serial_menu.style.display = "block";
//} 
//else 
//PC_based_Serial_menu.style.display = "none";
//}
//if (document.images['PC_based_Serial_arrow'].src == "/images/lft_m_arrow_d.gif")
//{
//document.images['PC_based_Serial_arrow'].src = '/images/lft_m_arrow_r.gif'
}

function function_Serial_Device_Servers_menu()
{ 
//if( Serial_Device_Servers_menu.style.display == "none") 
//{
//Serial_Device_Servers_menu.style.display = "block";
//else 
//Serial_Device_Servers_menu.style.display = "none";
//}
//if (document.images['Serial_Device_Servers_arrow'].src == "/images/lft_m_arrow_d.gif")
//{
//document.images['Serial_Device_Servers_arrow'].src = '/images/lft_m_arrow_r.gif'
}

function accessories_menu()
{ 
//if( accessories.style.display == "none") 
//{
//accessories.style.display = "block";
//} 
//else 
//accessories.style.display = "none";

}
	



/***********************************************
* Pop-it menu- c Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

