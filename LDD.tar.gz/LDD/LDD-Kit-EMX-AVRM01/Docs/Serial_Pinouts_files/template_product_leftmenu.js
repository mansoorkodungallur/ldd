

var str='';
str = str + '<table width="160" border="0" cellspacing="0" cellpadding="0" class="leftmenu">';
str=str + '<tr><td>'
//str = str + '                  <table width="160" class="leftmenublue" height="25" border="0" cellpadding="0" cellspacing="0"> ';
//str = str + '                    <tr bgcolor="f2f2f2">  ';
//str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
//str = str + '                      <td width="4"></td>  <td height="30" valign="middle" align="center"><a  href="index.htm" class="oran-11-b">Products</a> </td>  <td width="20"   valign="middle">&nbsp</td> ';
//str = str + '                    </tr> ';
//str = str + '                  </table></td> ';
//str = str + '	<tr><form name="prod_search" method="get" action="/product/search_results.asp">';
//str = str + '		<td height="40" class="leftmenublue" ><img src="/images/spacer.gif" width="3" height="5"> ';
//str = str + '		<input name="keyword" type="text" class="input-product-search" value="Product Search" size="12" onFocus=prod_search.keyword.value=""> ';
//str = str + '		<input name="go" type="submit" class="btn-go2" value="Go"></td></form> ';
str = str + '		</td></tr>';
//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr id="Industrial_Ethernet_Switches" > '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table class="leftmenublue"   width="160" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                    <td width="4"></td> <td height="30" valign="middle"><a  class="lft-m-green-b"  href="/product/Industrial_Ethernet_Switches.htm" >Industrial Ethernet Switches </a></td> <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[1])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td> ';//str = str + '                      <td valign="bottom"><a onMouseover="showmenu(event,linkset[1])" onMouseout="delayhidemenu()" href="/product/Industrial_Ethernet_Switches.htm" ><img  border="0" src="/images/tri.gif"></a></td> ';

str = str + '                    </tr> ';

str = str + '                  </table></td> ';
str = str + '              </tr> ';


//Serial to Ethernet

//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30">  ';
str = str + '                  <table width="160" class="leftmenublue" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                      <td width="4"></td>  <td height="30" valign="middle"><a  href="/product/Serial_to_Ethernet_Products.htm" class="lft-m-green-b">Serial to Ethernet <br>Products</a> </td>  <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[5])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td> ';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';

//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;




 // Wireless Ethernet
 
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table class="leftmenublue" width="160" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                       <td width="4"></td> <td  height="30" valign="middle" ><a     class="lft-m-green-b" href="/product/Wireless_Ethernet_products.htm">Wireless Ethernet Products</a></td> <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[2])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td> ';
//str = str + '                      <td valign="bottom"><a  ><img  border="0" src="/images/tri.gif"><img  border="0" src="/images/tri.gif"></a></td> ';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';



// Ethernet I/O products

//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table width="160" class="leftmenublue" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                       <td width="4"></td> <td height="30" valign="middle" ><a  href="/product/Remote_IO_Server.htm" class="lft-m-green-b">Remote I/O Servers</a></td>  <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[9])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td>';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';



//Embedded Computers
//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table width="160" class="leftmenublue" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                       <td width="4"></td> <td  height="30" valign="middle" ><a  href="/product/Embedded_Computers.htm" class="lft-m-green-b">Embedded Computers</a></td> <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[3])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td> ';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';



//MSB

//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table width="160" class="leftmenublue" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                       <td width="4"></td> <td  height="30" valign="middle"><a  href="/product/Multiport_Serial_Boards.htm" class="lft-m-green-b">Multiport Serial Boards</a></td>  <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[6])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td> ';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';




//Media Conventers
//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table width="160" class="leftmenublue" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                      <td width="4"></td>  <td height="30" valign="middle"><a  href="/product/Media_Converters.htm" class="lft-m-green-b">Media Converters</a> </td>  <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[7])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td> ';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';


// USB to serial HUB

//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table width="160" height="25" class="LeftMenuBlue" border="0" cellpadding="0" cellspacing="0"  > ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top" ><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                      <td width="4"></td>  <td height="30"  valign="middle"><a href="/product/USB_to_Serial_Hubs.htm" class="lft-m-green-b">USB to Serial Hubs</a> </td>   <td width="20"   valign="middle"><a onMouseover="showmenu(event,linkset[8])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td>';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';




//video over IP

//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table width="160" class="leftmenublue" height="25" border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                       <td width="4"></td> <td height="30" valign="middle" ><a  href="/product/Video_Servers.htm" class="lft-m-green-b">Video Servers</a></td>  <td width="20"   valign="middle"><a href="#" onMouseover="showmenu(event,linkset[4])" onMouseout="delayhidemenu()"><img border="0" src="../../images/ico_more.gif"></a></td>';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';



// Software  & Accessories

//str = str + '		<tr> ';
//str = str + '			<td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ' ;
//str = str + '		</tr>' ;
 
str = str + '              <tr> '; 
str = str + '                <td height="30" >  ';
str = str + '                  <table width="160" height="25" class="LeftMenuBlue" style="border-bottom:#cccccc 1px double"  border="0" cellpadding="0" cellspacing="0"> ';
str = str + '                    <tr>  ';
str = str + '                      <td valign="top"><!--<img src="/images/lft_m_arrow_r.gif" width="10" height="11" hspace="2" vspace="4" name="Embedded___Programmable_arrow" >--></td> ';
str = str + '                      <td width="4"></td>  <td  height="30" valign="middle"><a href="/product/Software_Accessories.htm" class="lft-m-green-b">Software & Accessories</a> </td> ';
str = str + '                    </tr> ';
str = str + '                  </table></td> ';
str = str + '              </tr> ';



//str = str + '                <td><img src="/images/lft_m_sep_1.gif" width="160" height="2"></td> ';
//str = str + '              </tr> '; 	  
str = str + '            </table>	 ';	
document.write (str);



