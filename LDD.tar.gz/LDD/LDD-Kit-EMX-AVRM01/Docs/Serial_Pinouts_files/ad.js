var Img_Banner = new Array();
Img_Banner[0]=new bannerSetting('','','top_banner5.jpg')
var Img_Right = new Array();Img_Right[0]=new bannerSetting('http://www.moxa.com/support/free_downloads.htm','','free_downloads468x60.gif')
var Img_Left = new Array();Img_Left[0]=new bannerSetting('http://www.moxa.com/product/Wireless_Serial_Device_Servers.htm','Cut the worry out of Wireless---Wireless NPort Series; Wireless Device Servers','W_NPort_banner.gif')
Img_Left[1]=new bannerSetting('http://www.moxa.com/product/EDS-726.htm','Gigabit your Industrial Ethernet with EDS-726','EDS-726_banner.gif')
var Img_RT1 = new Array();Img_RT1[0]=new bannerSetting('http://www.moxa.com/wireless','Wireless Device Server Daily Winner','w2150-190_90.gif')
var Img_RT2 = new Array();Img_RT2[0]=new bannerSetting('http://www.moxa.com/e-dm/tech/2004/NE/index.htm','FREE Starter Kits for Embedded Device Servers','NE_Starter_Kit_banner.gif')



function bannerSetting(url,alt,banner)
	{
	this.url = url;
	this.alt = alt;
	this.banner = banner;
	}

function show(strTag,width,height)
{
	var obj = eval('Img_'+strTag);
	
	if(obj.length>0)
	{
		var now = new Date();
		var sec = now.getSeconds();
		var ad = sec % obj.length;
	
	if(ad>obj.length-1||ad<0)
		{
			ad = obj.length;
		}
	if(obj[ad].url!='')
	{
	document.write('<a href=\"' + obj[ad].url + '\" target=\"_top\">');
	document.write('<img src="\\images\\' + obj[ad].banner + '\" width=');
	document.write(width + ' height=' + height + ' ');
	document.write('alt=\"' + obj[ad].alt + '\" border=0></a>');
	}
	else
	{
	document.write('<img src="\\images\\' + obj[ad].banner + '\" width=');
	document.write(width + ' height=' + height + ' ');
	document.write('alt=\"' + obj[ad].alt + '\" border=0>');
	}
	
	}

}

